package com.example.flutter_web_kue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
